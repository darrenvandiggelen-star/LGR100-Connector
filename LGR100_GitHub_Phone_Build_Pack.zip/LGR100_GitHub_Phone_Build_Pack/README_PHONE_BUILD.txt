LG 360 VR CONNECTOR V0.1 — BUILD APK FROM YOUR HUAWEI P50 PRO
================================================================

You do NOT need Android Studio, a PC, root, Google Play Services, or a local Android SDK.
GitHub Actions does the compilation in the cloud.

EASIEST PHONE METHOD
--------------------
The separate Phone Build Pack contains:
  1. LGR100_Source.zip
  2. WORKFLOW_build-apk.yml
  3. README_PHONE_BUILD.txt

On your Huawei:

1. Go to https://github.com and sign in.
2. Create a new repository. Example name: LGR100-Connector
   - Public or Private is fine.
   - Tick "Add a README file" so the repository is created with a main branch.
3. Open the new repository.
4. Tap Add file > Upload files.
5. Upload ONLY LGR100_Source.zip and commit it to the main branch.
6. Tap Add file > Create new file.
7. In the filename box enter EXACTLY:
      .github/workflows/build-apk.yml
8. Open WORKFLOW_build-apk.yml from the Phone Build Pack on your phone,
   copy all its text, and paste it into the GitHub editor.
9. Tap Commit changes.
10. Open the Actions tab in the repository.
11. Select "Build LGR100 APK".
12. Tap "Run workflow" > "Run workflow".
13. When the run has a green check mark, open it.
14. Scroll to Artifacts and tap:
      LGR100-Connector-APK
15. GitHub downloads a ZIP. Extract it on the Huawei.
16. Inside is:
      LGR100-Connector-V0.1-debug.apk
17. Tap the APK and allow installation from your browser/file manager if Huawei asks.

FIRST HEADSET TEST
------------------
1. Open LG 360 VR Connector.
2. Connect the LG 360 VR / LGR100 directly to the P50 Pro USB-C port.
3. Accept the USB permission prompt.
4. Press ACTIVATE HEADSET.
5. Watch the diagnostic log.
6. If an external display is detected, press SHOW VR TEST DISPLAY.
7. If it does not work, use COPY DIAGNOSTIC LOG and send the complete log back to ChatGPT.

BUILD DETAILS
-------------
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Java: 17
- compileSdk: 35
- targetSdk: 35
- minSdk: 26
- Output: debug APK, automatically signed with Android's debug key

NOTES
-----
- GitHub may show an Actions permission/setup screen the first time. Enable Actions for the repo if prompted.
- The artifact is a ZIP because GitHub packages downloadable workflow artifacts that way.
- The APK is a development/test build. It is not intended for Play Store distribution.
